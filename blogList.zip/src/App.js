import Routing from './routes'


function App() {
  return (
    <div>
      <Routing/>  
    </div>
  );
}

export default App;
