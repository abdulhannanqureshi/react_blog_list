import { blogLogics } from './blogLogic';

const AllLogics = [...blogLogics];

export default AllLogics;
