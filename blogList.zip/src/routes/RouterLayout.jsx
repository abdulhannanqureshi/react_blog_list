import React from 'react';

const RouterLayout = ({ children }) => {
  return <div>{children}</div>;
};
export default RouterLayout;
