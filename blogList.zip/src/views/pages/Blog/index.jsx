import React from 'react'
import BlogComponent from '../../component/BlogComponent'

const Blog = () => {
    return(
        <div>
            <BlogComponent />
        </div>
    )
}

export default Blog;