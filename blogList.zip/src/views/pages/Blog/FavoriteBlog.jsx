import React from 'react'
import FavouriteBlogComponent from '../../component/BlogComponent/FavouriteBlogComponent'

const FavoriteBlog = () => {
    return(
        <FavouriteBlogComponent/>
    )
}

export default FavoriteBlog;