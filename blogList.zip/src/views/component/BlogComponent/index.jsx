import React from 'react';
import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import BlogCardComponent from './BlogCardComponent';
import { useSelector, useDispatch } from 'react-redux';
import { blogRequest } from '../../../redux/action';
import { Link } from 'react-router-dom';
import { useHistory } from 'react-router-dom';

const BlogComponent = () => {
  const { blogReducer } = useSelector((state) => state);
  const dispatch = useDispatch();
  const addFavourite = (blogId) => {
    dispatch(blogRequest(blogId));
  };

  const history = useHistory();
  const editBlog = (blogId) => {
    history.push(`/edit-blog/${blogId}`);
  };
  return (
    <div className='blog-wrapper'>
      <Container>
        <Row className='text-right mb-3'>
          <Col md='12'>
            <Link to={'/add-blog'} className='btn btn-secondary'>
              Add Blog
            </Link>
            <Link to={'/favorite-blog'} className='btn btn-secondary ml-2'>
              Favorite Blog
            </Link>
          </Col>
        </Row>
        <Row>
          {blogReducer &&
          blogReducer.blogList &&
          blogReducer.blogList.length ? (
            blogReducer.blogList.map((item) => (
              <Col md='4' key={item.id}>
                <BlogCardComponent
                  blog={item}
                  addFavourite={addFavourite}
                  editBlog={editBlog}
                />
              </Col>
            ))
          ) : (
            <Col md='12' className='blog-empty'>
              <h2>Blog is empty</h2>
            </Col>
          )}
        </Row>
      </Container>
    </div>
  );
};
export default BlogComponent;
